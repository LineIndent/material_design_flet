from styles.theme import flet_material_theme
from styles.fonts import font_scheme
from styles.admonition_style import admonitions_color_scheme
from styles.badge_style import badge_size_dimensions, badge_icon
from styles.alert_style import alert_dimension, alert_settings
