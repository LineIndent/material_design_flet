from command.new_project import init_code
